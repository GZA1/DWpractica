<?php
/**
 * Obtiene todos los usuarios
 * 
 * @return array
 */
function usuarios_get_all() 
{    
    $usuarios = [];

    $data = json_decode(file_get_contents('e8_data1.json'), true);
    foreach($data as &$u) {
        $usuarios[$u['id']] = $u;
    }

    return $usuarios;
}

/**
 * Comprueba si un usuario existe
 * 
 * @param integer $uid  Identificador de usuario
 * 
 * @return array|null
 */
function usuarios_existe($uid) 
{    
    $usuarios = usuarios_get_all();

    if( is_numeric($uid) && isset($usuarios[$uid]) ) {
        return $usuarios[$uid];
    }
    return null;
}

/**
 * Añade un usuario nuevo
 * 
 * @param string $nombre        Nombre de usuario
 * @param string $apellidos     Apellidos de usuario
 * 
 * @return array
 */
function usuarios_add($nombre, $apellidos)
{
    $usuarios = usuarios_get_all();

    $id = max( array_keys($usuarios) );

    $newusu = [
        'id' => $id+1,
        'nombre' => $nombre,
        'apellidos' => $apellidos
    ];

    $usuarios[$newusu['id']] = $newusu;
    file_put_contents('e8_data1.json', json_encode($usuarios));

    return $newusu;
}

/**
 * Edita un usuario
 * 
 * @param integer $id           Id de usuario
 * @param string $nombre        Nombre de usuario
 * @param string $apellidos     Apellidos de usuario
 * 
 * @return array
 */
function usuarios_edit($id, $nombre, $apellidos)
{
    $usuarios = usuarios_get_all();
    
    if( isset($usuarios[$id]) ) {
        $usuarios[$id]['nombre'] = $nombre;
        $usuarios[$id]['apellidos'] = $apellidos;
       
        file_put_contents('e8_data1.json', json_encode($usuarios));
    
        return $usuarios[$id];    
    }
    return null;
}

/**
 * Edita un usuario
 * 
 * @param integer $id           Id de usuario
 * 
 * @return boolean
 */
function usuarios_delete($id)
{
    $usuarios = usuarios_get_all();
    
    if( isset($usuarios[$id]) ) {
        // Lo borramos
        unset($usuarios[$id]);
        file_put_contents('e8_data1.json', json_encode($usuarios));
        return true;
    }
    return false;
}



