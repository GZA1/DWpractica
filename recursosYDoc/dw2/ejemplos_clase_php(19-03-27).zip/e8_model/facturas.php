<?php

function facturas_get_all() 
{    
    $facturas = json_decode(file_get_contents('e8_data2.json'), true);

    return $facturas;
}


function facturas_get_for_user($user_id) 
{
    $facturas = [];

    $facturas_tmp = facturas_get_all();

    foreach($facturas_tmp as $f) {
        if( $f['user_id'] == $user_id ) {
            $facturas[] = $f;
        }
    }

    return $facturas;
}



