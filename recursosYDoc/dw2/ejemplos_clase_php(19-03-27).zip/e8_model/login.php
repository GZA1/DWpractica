<?php
/**
 * Obtiene todos los login
 * 
 * @return array
 */
function login_get_all() 
{    
    $usuarios = [];

    $data = json_decode(file_get_contents('/xampp/appdata/e8/e8_login.json'), true);
    foreach($data as &$u) {
        $usuarios[$u['username']] = $u;
    }

    return $usuarios;
}

/**
 * Comprueba si un login existe
 * 
 * @param string $username  Username
 * @param string $password  Password
 * 
 * @return array|null
 */
function login_check($username, $password) 
{    
    $logins = login_get_all();

    if( isset($logins[$username]) ) {
        if( $logins[$username]['password']==$password ) {
            return true;
        }
    }
    return false;
}
?>