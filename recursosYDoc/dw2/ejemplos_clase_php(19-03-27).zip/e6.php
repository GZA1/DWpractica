<!DOCTYPE html>
<html>
<head>
    <title>Ejemplo 4  PHP (ficha de empleado)</title>
</head>
<body>
    <p>Cadena: "Hola mundo. Que tal?"</p>
    <?php $cadena = "Hola mundo. Que tal?";?>
    <ul>
        <li>strtolower: <?php echo strtolower($cadena);?></li>
        <li>strtoupper: <?php echo strtoupper($cadena);?></li>
        <li>explode: 
        <?php 
            $words = explode(' ',$cadena);
            print_r($words);
        ?>
        </li>        
        <li>implode: 
        <?php 
            echo implode("-",$words);
        ?>  
        </li>          
        <li>strlen: <?php echo strlen($cadena);?></li>    
        <li>md5: <?php echo md5($cadena);?></li> 
        <li>str_word_count: <?php echo str_word_count($cadena, 0, " ");?></li> 
        <li>str_replace: <?php echo str_replace([' ','.'],['+','_'],$cadena);?></li>
        <li>str_replace (uso de limpieza): <?php echo str_replace([' ','.'],['',''],$cadena);?></li>
    </ul>
</body>
</html> 
    