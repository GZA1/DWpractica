<?php
    require_once 'e8_model/usuarios.php';

    if( isset($_GET['id']) && is_numeric($_GET['id']) )
    {
        $res = usuarios_delete($_GET['id']);

        if( $res ) {
            header('Location: e8_list_users.php');
            exit;
        }
        else {
            // Redirigir a pagina de error o mensaje
            echo "Error al borrar usuario";
            exit;
        }
    }
    else {
        echo "Datos incorrectos";
        exit;
    }
?>
