<!DOCTYPE html>
<html>
<head>
    <title>Ejemplo 1  PHP</title>
</head>
<body>
    <p>El primer script de PHP</p>
    <!-- Estilo 1. RECOMENDADO -->
    <p>
        <?php echo "Esto está generado con PHP"; ?>
    </p>
    <!-- Estilo 2 -->
    <?php
        // Imprimo por salida estandar
        echo "<p>Esto también</p>";        
    ?>
</body>
</html>