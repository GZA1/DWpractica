<?php
    require_once 'e4_datos.php';

    $id = $_GET['id'];

    $empl = null;
    foreach($empleados as $dni => $e) {
        if( $e['id']==$id ) {
            $empl = $e;
            $empl['dni'] = $dni;
            break;
        }
    }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ejemplo 4  PHP (ficha de empleado)</title>
</head>
<body>
    <table>
        <tr>
            <td>ID</td>
            <td><?php echo $empl['id'] ?></td>
        </tr>
        <tr>
            <td>Nombre</td>
            <td><?php echo $empl['nombre'] ?></td>
        </tr>
        <tr>
            <td>Apellidos</td>
            <td><?php echo $empl['apellidos'] ?></td>
        </tr>
        <tr>
            <td>Dni</td>
            <td><?php echo $empl['dni'] ?></td>
        </tr>
    </table>
</body>
</html>