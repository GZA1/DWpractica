<?php
    require_once 'e8_model/usuarios.php';
    require_once 'e8_model/facturas.php';

    session_start();  

    $users = usuarios_get_all();
    foreach($users as &$u) {
        $facturas_u = facturas_get_for_user($u['id']);
        $u['facturas'] = $facturas_u;
    }

    /*
        Ahora un usuario es una array como
        [
            'id' => ...,
            'nombre' => ...
            'apellidos' => ...
            'facturas => []
        ]
    */
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ejemplo 8  Listado de usuarios (combinado)</title>
</head>
<body>
    <table>
        <thead>
            <th>ID</th>
            <th>NOMBRE</th>
            <th>APELLIDOS</th>
            <?php if( isset($_SESSION['app1263467367346_islogged']) ) { ?>
            <th>N FACTURAS</th>
            <th>ACCIONES</th>
            <?php } ?>
        </thead>
        <tbody>
            <?php foreach($users as $u) : ?>
                <tr>
                    <td><?php echo $u['id'];?></td>
                    <td><?php echo $u['nombre'];?></td>
                    <td><?php echo $u['apellidos'];?></td>
                    <?php if( isset($_SESSION['app1263467367346_islogged']) ) { ?>
                    <td>
                        <?php 
                            if( count($u['facturas'])>0 ) {
                                echo "<a target='_blank' href='e8.php?uid=".$u['id']."'>".count($u['facturas'])."</a>";                        
                            }
                            else {
                                echo "0";
                            }
                        ?>                    
                    </td>
                    <td style="font-size: 0.6em">
                        <a href="e8_edit.php?id=<?php echo $u['id'];?>">Editar</a>
                        <a href="e8_delete.php?id=<?php echo $u['id'];?>">Borrar</a>
                    </td>
                    <?php } ?>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
<?php
?>