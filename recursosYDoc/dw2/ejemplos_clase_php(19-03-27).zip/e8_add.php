<?php
    require_once 'e8_model/usuarios.php';
    if( $_SERVER['REQUEST_METHOD']=='GET') {
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ejemplo 8  Uso de funciones</title>
</head>
<body>
    <form method="post">
        <p>
            Nombre <input type="text" id="nombre" name="nombre" />
        </p>
        <p>
            Apellidos <input type="text" id="apellidos" name="apellidos" />
        </p>
        <p>
            <input type="submit" value="Guardar" />
        </p>
    </form>
</body>
</html>
<?php
    }
    else if( $_SERVER['REQUEST_METHOD']=='POST') {
        // Añado al usuario
        $u = usuarios_add($_POST['nombre'], $_POST['apellidos']);
        if( $u ) {
            header('Location: e8_list_users.php');
            exit;
        }
        else {
            // Mostrar error o redirigir a error
            echo "Error: Falló la operación";
        }
    }
?>