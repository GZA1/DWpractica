<?php
class Empleado extends Persona
{
    protected $eid;

    public function __construct()
    {
        parent::__construct();
        $this->id = uniqid('e_');
    }

    /**
     * Get the value of eid
     */ 
    public function getEid()
    {
        return $this->eid;
    }

    /**
     * Set the value of eid
     *
     * @return  self
     */ 
    public function setEid($eid)
    {
        $this->eid = $eid;

        return $this;
    }
}