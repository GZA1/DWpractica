<?php
class Cliente extends Persona
{
    protected $cid;

    public function __construct()
    {
        parent::__construct();
    }

    /**
     * Get the value of cid
     */ 
    public function getCid()
    {
        return $this->cid;
    }

    /**
     * Set the value of cid
     *
     * @return  self
     */ 
    public function setCid($cid)
    {
        $this->cid = $cid;

        return $this;
    }

    public function isEmpleado()
    {
        // Codigo que recupera la lista de empleados y busca uno
        // cuyo dni coincida con el de este cliente
        // if( $this->dni == $em->getDni() ) {
        //   return true;
        // }
        return false;
    }

    public function toJson()
    {
        return json_encode([
           'cid'=>$this->cid,
           'nombre'=>$this->nombre,
           'apellidos'=>$this->apellidos,
           'dni'=>$this->dni,
        ]);
    }

    public static function fromJson($json)
    {
        $array = json_decode($json, true);
        $obj = new Cliente();
        $obj->setNombre($array['nombre'])
            ->setApellidos($array['apellidos'])
            ->setDni($array['dni'])
            ->setCid($array['cid'])
        ;
        return $obj;
    }
}