<?php
    require_once 'e4_datos.php';
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ejemplo 4  PHP</title>
</head>
<body>
    <!-- Empleados -->
    <p>Lista de empleados</p>
    <table>
        <thead>
            <th>ID</th>
            <th>Nombre</th>
            <th>Apellidos</th>
            <th>Dni</th>
            <th></th>
        </thead>
        <tbody>
            <?php
                foreach($empleados as $dni => $e) {
            ?>
            <tr>
                <td><?php echo $e['id']; ?></td>
                <td><?php echo $e['nombre']; ?></td>
                <td><?php echo $e['apellidos']; ?></td>
                <td><?php echo $dni; ?></td>
                <td><a href="e4_empleado.php?id=<?php echo $e['id'] ?>">Ver</a></td>
            </tr>
            <?php
                }
            ?>
        </tbody>
    </table>

    <!-- Clientes -->
    <p>Lista de clientes</p>
        <table>
            <thead>
                <th>Dni</th>
                <th>Nombre</th>
                <th>Apellidos</th>
            </thead>
            <tbody>
                <?php foreach($empleados as $dni => $e) : ?>
                <tr>
                    <td><?php echo $dni; ?></td>
                    <td><?php echo $e['nombre']; ?></td>
                    <td><?php echo $e['apellidos']; ?></td>
                </tr>
                <?php endforeach ?>
            </tbody>
        </table>    
</body>
</html>