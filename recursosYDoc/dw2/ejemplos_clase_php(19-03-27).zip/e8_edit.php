<?php
    require_once 'e8_model/usuarios.php';

    if( $_SERVER['REQUEST_METHOD']=='GET') {
        
        $u = usuarios_existe($_GET['id']);
        if( !$u ) {
            // Redirigir a error o mensaje
            echo "Usuario incorrecto";
            exit;
        }
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ejemplo 8  Editar usuario</title>
</head>
<body>
    <form method="post">
        <p>
            Nombre <input type="text" id="nombre" name="nombre" value="<?php echo $u['nombre'];?>" />
        </p>
        <p>
            Apellidos <input type="text" id="apellidos" name="apellidos" value="<?php echo $u['apellidos'];?>" />
        </p>
        <p>
            <input type="submit" value="Guardar" />
        </p>
    </form>
</body>
</html>
<?php
    }
    else if( $_SERVER['REQUEST_METHOD']=='POST') {
        // Edito al usuario
        $u = usuarios_edit($_GET['id'], $_POST['nombre'], $_POST['apellidos']);
        if( $u ) {
            header('Location: e8_list_users.php');
            exit;
        }
        else {
            // Mostrar error o redirigir a error
            echo "Error: Falló la operación";
        }
    }
?>