<!DOCTYPE html>
<html>
<head>
    <title>Ejemplo 1  PHP</title>
</head>
<body>
    <?php
       // Arrays indexados
       // $array1 = array(1,2,3,5,8,10);    Sintaxis antigua
       $array1 = [1,2,3,5,8,10];
       $array1[6] = 11;
       $array1[] = 12;
       $array1[] = "13";

       // Arrays asociativos
       $array2 = [
            'clave1' => 23,
            'clave2' => "hola"
       ];
       $array2['clave3'] = 4.5;
       $array2['clave4'] = ['a'=>1, 'b'=>2];

       $array2['clave4']['a']++;

       $array3 = [14,15,10];

       // Eliminar un elemento concreto
       unset($array2['clave2']);

       // Tamaño (en numero elementos) de un array
       echo count($array1).' '.count($array2); 
       
       // Union de arrays
       print_r($array1 + $array3);
       print_r($array3 + $array1);
    ?>
</body>
</html>