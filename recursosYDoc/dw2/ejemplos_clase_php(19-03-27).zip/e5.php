<!DOCTYPE html>
<html>
<head>
    <title>Ejemplo 4  PHP (ficha de empleado)</title>
</head>
<body>
    <p>Hora actual: 
    <?php
        echo date("d/m/Y \a \l\a\s H:i:s");
    ?>
    date("d/m/Y \a \l\a\s H:i:s")
    </p>
    <p>Hora en formato ISO: 
    <?php
        echo date("Y-m-d H:i:s");
    ?>
    </p>   
    date("Y-m-d H:i:s") 
    <p>Identificador "unico" temporal: 
    <?php
        echo date("YmdHis");
    ?>
    </p> 
    date("YmdHis")  
    <p>Unixtime o timestamp: 
    <?php
        echo time();
    ?>
    </p> 
    time()
    <p>Create from format: 
    <?php
        $fechaUsuario = "03/03/2015 12:34:56";
        $date = date_create_from_format("d/m/Y H:i:s", $fechaUsuario);
        echo $date->format("Y-m-d H:i:s");
    ?>
    </p> 
       
</body>
</html>