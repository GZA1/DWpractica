<?php
    require_once 'e8_model/usuarios.php';
    require_once 'e8_model/facturas.php';

    if( isset($_GET['uid']) && usuarios_existe($_GET['uid'])!==null ) {
        $uid = $_GET['uid'];
        $facturas = facturas_get_for_user($uid);
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ejemplo 8  Uso de funciones</title>
</head>
<body>
    <table>
        <thead>
            <th>ID</th>
            <th>USER</th>
            <th>CANTIDAD (€)</th>
        </thead>
        <tbody>
            <?php foreach($facturas as $f) : ?>
                <tr>
                    <td><?php echo $f['id'];?></td>
                    <td><?php echo $f['user_id'];?></td>
                    <td><?php echo $f['cantidad'];?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
<?php
    }
    else {
        echo "Error: UID no valido";        
    }
?>