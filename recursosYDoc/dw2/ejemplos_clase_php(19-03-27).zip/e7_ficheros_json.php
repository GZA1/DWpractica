<?php
    $datos = [
        ['nombre'=>'AAA', 'apellidos'=>'AAA', 'dni'=>'111111A'],
        ['nombre'=>'BBB', 'apellidos'=>'BBB', 'dni'=>'111111B'],
        ['nombre'=>'CCC', 'apellidos'=>'CCC', 'dni'=>'111111C']
    ];

    file_put_contents("datos.json", json_encode($datos));

    $datos2 = json_decode(file_get_contents("datos.json"),true);
    print_r($datos2);

    
