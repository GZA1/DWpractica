<?php
    require_once('model_clientes.php');

    if( $_SERVER['REQUEST_METHOD']=='GET' ) {

    }
    else if( $_SERVER['REQUEST_METHOD']=='POST' ) {

        // Validacion de datos 
        
        $usuarioId = clientes_add($_POST['nombre'], $_POST['apellidos'], $_POST['username'], $_POST['password'], $_POST['clienteId']); 

        header("Location: list_clientes.php");
        exit;
    }
?>
<html>
<head>
</head>
<body>
    <form method="post">
        <input type="hidden" name="tipo" value="cliente" />
        <p>
            Nombre: <input type="text" name="nombre" id="nombre" />
        </p>
        <p>
            Apellidos: <input type="text" name="apellidos" id="apellidos" />
        </p>
        <p>
            Username: <input type="text" name="username" id="username" />
        </p>
        <p>
            Password: <input type="password" name="password" id="password" />
        </p>
        <p>
            Cliente ID: <input type="text" name="clienteId" id="clienteId" />
        </p>   
        <p>
            <button>Guardar</button>
        </p>                     
    </form>
</body>
</html>
<?php
function cliente_existe($clienteId) {
    return false;
}
?>