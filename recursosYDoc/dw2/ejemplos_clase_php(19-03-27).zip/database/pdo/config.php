<?php
function db()
{
    try{
        $conn = new PDO('mysql:host=localhost;port=3307;dbname=bd_ejemplo;charset=utf8', 'root', '');
        return $conn;
    }
    catch(PDOException $pe) {
        echo $pe->getMessage();
    }    
    return null;
}
