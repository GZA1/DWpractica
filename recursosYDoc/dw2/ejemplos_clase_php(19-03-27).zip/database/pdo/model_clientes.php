<?php
require_once("config.php");

/**
 * Obtiene todos los clientes
 * 
 * @return array
 */
function clientes_get_all()
{
    $conn = db();

    $clientes = [];

    $SQL = "select * from usuarios where tipo='cliente'";

    $stmt = $conn->query($SQL);   
    if( $stmt===false ) {
        // Error;
        echo ($stmt->errorInfo())[2];
        exit;
    }
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $clientes[] = [
            'id' => $row['id'],
            'tipo' => $row['tipo'],
            'nombre' => $row['nombre'],
            'apellidos' => $row['apellidos'],
            'username' => $row['username'],
            'password' => $row['password'],
            'cliente_id' => $row['cliente_id'],
            'empleado_id' => $row['empleado_id']
        ];
    }

    return $clientes;
}

/**
 * Obtiene un cliente concreto
 * 
 * @return array
 */
function clientes_get($id)
{
    $conn = db();

    $cliente = null;

    $tipo = 'cliente';

    $SQL = "select * from usuarios where tipo = :tipo and id = :id";

    $stmt = $conn->prepare($SQL);   
    $stmt->bindParam(':tipo', $tipo);
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    
    $res = $stmt->execute();
    if( !$res ) {
        // Error
        echo ($stmt->errorInfo())[2];
        exit;
    }

    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    
    $cliente = [
        'id' => $row['id'],
        'tipo' => $row['tipo'],
        'nombre' => $row['nombre'],
        'apellidos' => $row['apellidos'],
        'username' => $row['username'],
        'password' => $row['password'],
        'cliente_id' => $row['cliente_id'],
        'empleado_id' => $row['empleado_id']
    ];

    return $cliente;
}

/**
 * Añade un nuevo cliente
 * 
 * @param string $nombre
 * @param string $apellidos
 * @param string $username
 * @param string $password
 * @param string $clienteId
 * 
 * @return integer
 */
function clientes_add($nombre, $apellidos, $username, $password, $clienteId)
{
    $conn = db();

    $SQL = "
            insert into usuarios (
                 tipo
                ,nombre
                ,apellidos
                ,username
                ,password
                ,cliente_id
                ,empleado_id
            ) values (
                 :tipo
                ,:nombre
                ,:apellidos
                ,:username
                ,:password
                ,:cliente_id
                ,:empleado_id
            )
        ";

        $tipo = 'cliente';
        $cliente_id = isset($clienteId) ? $clienteId : null;
        $empleado_id = null;

        $stmt = $conn->prepare($SQL);   
        $stmt->bindParam(':tipo', $tipo);
        $stmt->bindParam(':nombre', $nombre, PDO::PARAM_STR, 20);
        $stmt->bindParam(':apellidos', $apellidos);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $password);
        $stmt->bindParam(':cliente_id', $cliente_id, PDO::PARAM_STR);
        $stmt->bindParam(':empleado_id', $empleado_id, PDO::PARAM_STR);

        $stmt->execute();

        $usuarioId = $conn->lastInsertId();

        return $usuarioId;
}

/**
 * Edita un cliente existente
 * 
 * @return boolean
 */
function clientes_edit($id, $nombre, $apellidos, $username, $password, $clienteId)
{
    $conn = db();

    $SQL = "
            update usuarios set
                 nombre = :nombre
                ,apellidos = :apellidos
                ,username = :username
                ,password = :password
                ,cliente_id = :cliente_id
            where id = :id
        ";

        $clienteId = isset($clienteId) ? $clienteId : null;

        $stmt = $conn->prepare($SQL);   
        $stmt->bindParam(':nombre', $nombre);
        $stmt->bindParam(':apellidos', $apellidos);
        $stmt->bindParam(':username', $username);
        $stmt->bindParam(':password', $password);
        $stmt->bindParam(':cliente_id', $clienteId);
        $stmt->bindParam(':id', $id, PDO::PARAM_STR);
        
        $res = $stmt->execute();

        return $res;
}

/**
 * Elimina un cliente existente
 * 
 * @return boolean
 */
function clientes_delete($id)
{
    $conn = db();

    $SQL = "delete from usuarios where id = :id";

    $stmt = $conn->prepare($SQL);   
    $stmt->bindParam(':id', $id, PDO::PARAM_INT);
    $res = $stmt->execute();
    
    return $res;
}