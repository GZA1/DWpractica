<?php
    require_once("model_clientes.php");
    require_once("model_catalogo.php");
    
    $filtro = [];
    $withProductos = false;
    if( isset($_GET['full']) && $_GET['full']==true ) {
        $withProductos = true;
    }
    $categorias = catalogo_categorias_get_all($filtro, $withProductos);
?>
<html>
<head>
</head>
<body>
    <table>
        <thead>
            <th>ID</th> 
            <th>NOMBRE</th>
            <th>Nº Productos</th>
            <th>ACCIONES</th>
        </thead>
        <tbody>
            <?php foreach($categorias as $c) : ?>
                <tr>
                    <td><?php echo $c['id']; ?></td>
                    <td><?php echo $c['nombre']; ?></td>
                    <td>
                        <?php 
                            if( isset($c['productos']) ) {
                                echo count($c['productos']);
                            }
                        ?>
                    </td>
                    <td>
                        <a href="edit_categoria.php?id=<?php echo $c['id']?>">Editar</a>
                        <a href="delete_categoria.php?id=<?php echo $c['id']?>">Borrar</a>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</body>
</html>