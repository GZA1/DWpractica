<?php
    require_once('model_clientes.php');
    
    if( $_SERVER['REQUEST_METHOD']=='GET' ) {
        $usuario = clientes_get($_GET['id']);
    }
    else if( $_SERVER['REQUEST_METHOD']=='POST' ) {
        // Validacion de datos
        if( !isset($_POST['nombre']) ) {
            echo "Error1"; exit;
        }
        if( !isset($_POST['password']) || strlen($_POST['password'])<4 ) {
            echo "Error2"; exit;
        }   
        if( !isset($_POST['clienteId']) || cliente_existe($_POST['clienteId']) ) {
            echo "Error3"; exit;
        }     
        
        $result = clientes_edit($_GET['id'], $_POST['nombre'], $_POST['apellidos'], $_POST['username'], $_POST['password'], $_POST['clienteId']); 

        header("Location: list_clientes.php");
        exit;
    }
?>
<html>
<head>
</head>
<body>
    <form method="post">
        <input type="hidden" name="tipo" value="<?php echo $usuario['tipo'];?>" />
        <p>
            Nombre: <input type="text" name="nombre" id="nombre" value="<?php echo $usuario['nombre'];?>" />
        </p>
        <p>
            Apellidos: <input type="text" name="apellidos" id="apellidos" value="<?php echo $usuario['apellidos'];?>" />
        </p>
        <p>
            Username: <input type="text" name="username" id="username" value="<?php echo $usuario['username'];?>" />
        </p>
        <p>
            Password: <input type="password" name="password" id="password" value="<?php echo $usuario['password'];?>" />
        </p>
        <p>
            Cliente ID: <input type="text" name="clienteId" id="clienteId" value="<?php echo $usuario['cliente_id'];?>" />
        </p>   
        <p>
            <button>Guardar</button>
        </p>                     
    </form>
</body>
</html>
<?php
function cliente_existe($clienteId) {
    return false;
}
?>