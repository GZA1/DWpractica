<?php
require_once("config.php");

//----------------------------------------------------------------
//  FUNCIONES DE CATEGORIAS
//----------------------------------------------------------------

/**
 * Obtiene todas las categorias
 * 
 * @param array   $filtro           Opciones de recuperacion de categorias
 * @param boolean $withProductos    Obtiene las categorias con productos
 * 
 * @return array
 */
function catalogo_categorias_get_all($filtro = null, $withProductos = false)
{
    $conn = db();

    $categorias = [];

    $SQL = "select * from catalogo_categorias ";
    if( $filtro!=null ) {
        $whereSQL = "where ";
        if( isset($filtro['id']) ) {
            if( $whereSQL != "where " ) {
                $whereSQL .= "and ";
            }
            $whereSQL .= "id = '".$filtro['id']."' ";
        }        
        if( isset($filtro['nombre']) ) {
            if( $whereSQL != "where " ) {
                $whereSQL .= "and ";
            }
            $whereSQL .= "nombre = '".$filtro['catalogo_categorias_nombre']."' ";
        }
        $SQL .= $whereSQL;
    }

    $stmt = $conn->query($SQL);   
    if( $stmt===false ) {
        // Error;
        echo ($stmt->errorInfo())[2];
        exit;
    }
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $c = [
            'id' => $row['id'],
            'nombre' => $row['nombre']
        ];
        if( $withProductos ) {
            $c['productos'] = catalogo_productos_categoria($row['id']);
        }
        $categorias[] = $c;
    }

    return $categorias;
}

/**
 * Obtiene una categoria concreta
 * 
 * @param integer $id               Identificador de categoria
 * @param boolean $withProductos    Obtiene la categoria con productos
 * 
 * @return array
 */
function catalogo_categorias_get($id, $withProductos = false)
{
    return catalogo_categorias_get_all(['id'=>$id], $withProductos);
}

//----------------------------------------------------------------
//  FUNCIONES DE PRODUCTOS
//----------------------------------------------------------------

/**
 * Obtiene todos los productos
 * 
 * @param array   $filtro  Opciones de recuperacion de productos
 * 
 * @return array
 */
function catalogo_productos_get_all($filtro = null)
{
    $conn = db();

    $productos = [];

    $SQL = "select * from catalogo_productos ";
    if( $filtro!=null ) {
        $whereSQL = "where ";
        if( isset($filtro['catalogo_categorias_id']) ) {
            if( $whereSQL != "where " ) {
                $whereSQL .= "and ";
            }
            $whereSQL .= "catalogo_categorias_id = '".$filtro['catalogo_categorias_id']."' ";
        }
        if( isset($filtro['id']) ) {
            if( $whereSQL != "where " ) {
                $whereSQL .= "and ";
            }
            $whereSQL .= "id = '".$filtro['id']."' ";
        }
        $SQL .= $whereSQL;
    }

    $stmt = $conn->query($SQL);   
    if( $stmt===false ) {
        // Error;
        echo ($stmt->errorInfo())[2];
        exit;
    }
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $productos[] = [
            'id' => $row['id'],
            'nombre' => $row['nombre'],
            'precio' => $row['precio'],
            'catalogo_categorias_id' => $row['precio']
        ];
    }

    return $productos;
}

/**
 * Obtiene todos los productos de una categoria
 * 
 * @param integer $categoriaId   El Id de la categoria
 * 
 * @return array
 */
function catalogo_productos_categoria($categoriaId)
{
    return catalogo_productos_get_all(['catalogo_categorias_id' => $categoriaId]);    
}

//----------------------------------------------------------------
//  FUNCIONES DE FOTOS DE PRODUCTO
//----------------------------------------------------------------

function catalogo_productos_fotos_store($productoId, $fileData, $inline = false)
{
    // Almacenar en la ubicacion correcta y con el nombre correspondiente
    // el fichero subido
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimetype = $finfo->file($fileData['tmp_name']);
    $id = sha1_file($fileData['tmp_name']);

    // Insertar un registro en la base de datos
    $conn = db();

    if( !$inline ) {
        if( !is_dir('/xampp/appdata/catalogo/fotos') ) {
            mkdir('/xampp/appdata/catalogo/fotos',0777,true);
        }

        $filename = sprintf('/xampp/appdata/catalogo/fotos/%s',$id);
        move_uploaded_file(
            $fileData['tmp_name'],
            $filename
        );

        $SQL = "
            insert into catalogo_productos_fotos (
                            nombre,
                            mimetype,
                            path,
                            catalogo_productos_id
            ) values (
                '".$fileData['name']."',
                '".$mimetype."',
                '".$filename."',
                '".$productoId."'
            )
        ";        
    }
    else {
        $content = file_get_contents($fileData['tmp_name']);
        
        $content = base64_encode($content);            // Metodo 1 de securizar el contenido binario
        $content = $conn->escape_string($content);     // Metodo 2 de securizar el contenido binario

        $SQL = "
        insert into catalogo_productos_fotos (
                        nombre,
                        mimetype,
                        content,
                        catalogo_productos_id
        ) values (
            '".$fileData['name']."',
            '".$mimetype."',
            '".$content."',
            '".$productoId."'
        )
    ";  
    }

    $stmt = $conn->prepare($SQL);   
    $stmt->execute();

    $fotoId = $conn->lastInsertId();

    return $fotoId;
}