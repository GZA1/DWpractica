<?php
// 1. Establecer conexion a la base de datos
$conn = new mysqli("localhost", "root", "", "bd_ejemplo", 3307);
if ($conn->connect_error) {
    die('Error de Conexión (' . $conn->connect_errno . ') '
            . $conn->connect_error);
}
$conn->set_charset("utf8");

// 2. Validacion de datos
/*
if( !cliente_existe($_GET['id']) ) ) {
    echo "Error";
}
*/

// 3. Construimos la sentencia SQL de insercion
$SQL = "
    delete from usuarios where id = ".$_GET['id']."
";

// 4. Ejecutar la sentencia
$result = $conn->query($SQL);
if( !$result ) {
    echo $conn->error;
    echo "Error4"; exit;
}
// Opcional. En aplicaciones o datos criticos viene a continuación
// un select para comprobar datos

$conn->close();

header("Location: list_clientes.php");
exit;