<?php
    if( $_SERVER['REQUEST_METHOD']=='GET' ) {
        // 1. Establecer conexion a la base de datos
        $conn = new mysqli("localhost", "root", "", "bd_ejemplo", 3307);
        if ($conn->connect_error) {
            die('Error de Conexión (' . $conn->connect_errno . ') '
                    . $conn->connect_error);
        }
        $conn->set_charset("utf8");

        // 2. Creacion y ejecucion de la consulta
        $SQL = "select * from usuarios where id='".$_GET['id']."'";
        $result = $conn->query($SQL);   // result es un objeto de tipo mysqli_result
        $row = $result->fetch_assoc();
        $usuario = [
            'tipo' => $row['tipo'],
            'nombre' => $row['nombre'],
            'apellidos' => $row['apellidos'],
            'username' => $row['username'],
            'password' => $row['password'],
            'cliente_id' => $row['cliente_id']
        ];
        $result->free();

        // 3. Cerrar la conexion
        $conn->close();
    }
    else if( $_SERVER['REQUEST_METHOD']=='POST' ) {
        // 1. Establecer conexion a la base de datos
        $conn = new mysqli("localhost", "root", "", "bd_ejemplo", 3307);
        if ($conn->connect_error) {
            die('Error de Conexión (' . $conn->connect_errno . ') '
                    . $conn->connect_error);
        }
        $conn->set_charset("utf8");

        // 2. Validacion de datos
        if( !isset($_POST['nombre']) ) {
            echo "Error1"; exit;
        }
        if( !isset($_POST['password']) || strlen($_POST['password'])<4 ) {
            echo "Error2"; exit;
        }   
        if( !isset($_POST['clienteId']) || cliente_existe($_POST['clienteId']) ) {
            echo "Error3"; exit;
        }     
        
        // 3. Construimos la sentencia SQL de insercion
        $SQL = "
            update usuarios set
                 tipo = '".$_POST['tipo']."'
                ,nombre = '".$_POST['nombre']."'
                ,apellidos = '".$_POST['apellidos']."'
                ,username = '".$_POST['username']."'
                ,password = '".$_POST['password']."'
                ,cliente_id = ". (isset($_POST['clienteId']) ? "'".$_POST['clienteId']."'" : 'NULL')  ."
                ,empleado_id = ". (isset($_POST['empleado_id']) ? "'".$_POST['empleado_id']."'" : 'NULL')  ."
            where id = ".$_GET['id']."
        ";

        // 4. Ejecutar la sentencia
        $result = $conn->query($SQL);
        if( !$result ) {
            echo $conn->error;
            echo "Error4"; exit;
        }
        // Opcional. En aplicaciones o datos criticos viene a continuación
        // un select para comprobar datos

        $conn->close();

        header("Location: list_clientes.php");
        exit;
    }
?>
<html>
<head>
</head>
<body>
    <form method="post">
        <input type="hidden" name="tipo" value="<?php echo $usuario['tipo'];?>" />
        <p>
            Nombre: <input type="text" name="nombre" id="nombre" value="<?php echo $usuario['nombre'];?>" />
        </p>
        <p>
            Apellidos: <input type="text" name="apellidos" id="apellidos" value="<?php echo $usuario['apellidos'];?>" />
        </p>
        <p>
            Username: <input type="text" name="username" id="username" value="<?php echo $usuario['username'];?>" />
        </p>
        <p>
            Password: <input type="password" name="password" id="password" value="<?php echo $usuario['password'];?>" />
        </p>
        <p>
            Cliente ID: <input type="text" name="clienteId" id="clienteId" value="<?php echo $usuario['cliente_id'];?>" />
        </p>   
        <p>
            <button>Guardar</button>
        </p>                     
    </form>
</body>
</html>
<?php
function cliente_existe($clienteId) {
    return false;
}
?>