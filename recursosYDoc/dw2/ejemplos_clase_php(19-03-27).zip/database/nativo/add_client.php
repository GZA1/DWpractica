<?php
    if( $_SERVER['REQUEST_METHOD']=='GET' ) {

    }
    else if( $_SERVER['REQUEST_METHOD']=='POST' ) {
        // 1. Establecer conexion a la base de datos
        $conn = new mysqli("localhost", "root", "", "bd_ejemplo", 3307);
        if ($conn->connect_error) {
            die('Error de Conexión (' . $conn->connect_errno . ') '
                    . $conn->connect_error);
        }
        $conn->set_charset("utf8");

        // 2. Validacion de datos
        if( !isset($_POST['nombre']) ) {
            echo "Error"; exit;
        }
        if( !isset($_POST['password']) || strlen($_POST['password'])<4 ) {
            echo "Error"; exit;
        }   
        if( !isset($_POST['clienteId']) || cliente_existe($_POST['clienteId']) ) {
            echo "Error"; exit;
        }     
        
        // 3. Construimos la sentencia SQL de insercion
        $SQL = "
            insert into usuarios (
                 tipo
                ,nombre
                ,apellidos
                ,username
                ,password
                ,cliente_id
                ,empleado_id
            ) values (
                 '".$_POST['tipo']."'
                ,'".$_POST['nombre']."'
                ,'".$_POST['apellidos']."'
                ,'".$_POST['username']."'
                ,'".$_POST['password']."'
                ,". (isset($_POST['clienteId']) ? "'".$_POST['clienteId']."'" : 'NULL')  ."
                ,". (isset($_POST['empleado_id']) ? "'".$_POST['empleado_id']."'" : 'NULL')  ."
            )
        ";

        // 4. Ejecutar la sentencia
        $result = $conn->query($SQL);
        if( !$result ) {
            echo "Error"; exit;
        }
        // Opcional. En aplicaciones o datos criticos viene a continuación
        // un select para comprobar datos

        // Obtener el id autogenerado por la BD
        $usuarioId = $conn->insert_id;

        $conn->close();

        header("Location: list_clientes.php");
        exit;
    }
?>
<html>
<head>
</head>
<body>
    <form method="post">
        <input type="hidden" name="tipo" value="cliente" />
        <p>
            Nombre: <input type="text" name="nombre" id="nombre" />
        </p>
        <p>
            Apellidos: <input type="text" name="apellidos" id="apellidos" />
        </p>
        <p>
            Username: <input type="text" name="username" id="username" />
        </p>
        <p>
            Password: <input type="password" name="password" id="password" />
        </p>
        <p>
            Cliente ID: <input type="text" name="clienteId" id="clienteId" />
        </p>   
        <p>
            <button>Guardar</button>
        </p>                     
    </form>
</body>
</html>
<?php
function cliente_existe($clienteId) {
    return false;
}
?>