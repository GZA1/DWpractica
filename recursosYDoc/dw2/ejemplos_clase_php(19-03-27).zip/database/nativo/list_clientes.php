<?php
    $usuarios = [];

    // 1. Establecer conexion a la base de datos
    $conn = new mysqli("localhost", "root", "", "bd_ejemplo", 3307);
    if ($conn->connect_error) {
        die('Error de Conexión (' . $conn->connect_errno . ') '
                . $conn->connect_error);
    }
    $conn->set_charset("utf8");

    // 2. Creacion y ejecucion de la consulta
    $SQL = "select * from usuarios where tipo='cliente'";
    $result = $conn->query($SQL);   // result es un objeto de tipo mysqli_result
    while ($row = $result->fetch_assoc()) {
        $usuarios[] = [
            'id' => $row['id'],
            'nombre' => $row['nombre'],
            'apellidos' => $row['apellidos'],
            'username' => $row['username']
        ];
    }
    $result->free();

    // 3. Cerrar la conexion
    $conn->close();
?>
<html>
<head>
</head>
<body>
    <table>
        <thead>
            <th>NOMBRE</th> 
            <th>APELLIDOS</th>
            <th>USERNAME</th>
            <th>ACCIONES</th>
        </thead>
        <tbody>
            <?php foreach($usuarios as $u) : ?>
                <tr>
                    <td><?php echo $u['nombre']; ?></td>
                    <td><?php echo $u['apellidos']; ?></td>
                    <td><?php echo $u['username']; ?></td>
                    <td>
                        <a href="edit_client.php?id=<?php echo $u['id']?>">Editar</a>
                        <a href="delete_client.php?id=<?php echo $u['id']?>">Borrar</a>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</body>
</html>