<?php
require_once "config.php"

/**
 * Obtiene todos los clientes
 * 
 * @return array
 */
function clientes_get_all()
{
    $conn = db();

    $clientes = [];

    $SQL = "select * from usuarios where tipo='cliente'";

    $result = $conn->query($SQL);   
    while ($row = $result->fetch_assoc()) {
        $clientes[] = [
            'nombre' => $row['nombre'],
            'apellidos' => $row['apellidos'],
            'username' => $row['username']
        ];
    }
    $result->free();

    $conn->close();

    return $clientes;
}

function clientes_get($id)
{
    $conn = db();

    $clientes = [];

    $SQL = "select * from usuarios where id='".$id."'";

    $result = $conn->query($SQL);   
    $row = $result->fetch_assoc();
    $cliente[] = [
        'id' => $row['id'],
        'tipo' => $row['tipo'],
        'nombre' => $row['nombre'],
        'apellidos' => $row['apellidos'],
        'username' => $row['username'],
        'password' => $row['password'],
        'cliente_id' => $row['cliente_id'],
        'empleado_id' => $row['empleado_id']
    ];
    $result->free();

    $conn->close();

    return $clientes;
}

function clientes_add($nombre, $apellidos, $username, $password, $clienteId)
{
    $conn = db();

    $SQL = "
            insert into usuarios (
                 tipo
                ,nombre
                ,apellidos
                ,username
                ,password
                ,cliente_id
                ,empleado_id
            ) values (
                 'cliente'
                ,'".$nombre."'
                ,'".$apellidos."'
                ,'".$username."'
                ,'".$password."'
                ,". (isset($clienteId) ? "'".$clienteId."'" : 'NULL')  ."
                ,NULL
            )
        ";

        $result = $conn->query($SQL);
        if( !$result ) {
            echo "Error"; exit;
        }
        $usuarioId = $conn->insert_id;

        $conn->close();

        return $usuarioId;
}

function clientes_edit($id, $nombre, $apellidos, $username, $password, $clienteId)
{
    $conn = db();

    $SQL = "
            update usuarios set
                 nombre = '".$nombre."'
                ,apellidos = '".$apellidos."'
                ,username = '".$username."'
                ,password = '".$password."'
                ,cliente_id = ". (isset($clienteId) ? "'".$clienteId."'" : 'NULL')  ."
            where id = ".$id."
        ";

        $result = $conn->query($SQL);
        if( !$result ) {
            echo "Error"; exit;
        }

        $conn->close();

        return true;
}

function clientes_delete($id)
{
    $conn = db();

    $SQL = "
            delete from usuarios where id = ".$id."
        ";

        $result = $conn->query($SQL);
        if( !$result ) {
            echo "Error"; exit;
        }

        $conn->close();

        return true;
}