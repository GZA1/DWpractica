<?php
require_once "model_clientes.php"

// Validacion de datos
/*
if( !cliente_existe($_GET['id']) ) ) {
    echo "Error";
}
*/

clientes_delete($_GET['id'];)

$conn->close();

header("Location: list_clientes.php");
exit;