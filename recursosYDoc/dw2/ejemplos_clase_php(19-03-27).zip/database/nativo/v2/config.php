<?php
function db()
{
    $conn = new mysqli("localhost", "root", "", "bd_ejemplo", 3307);
    if ($conn->connect_error) {
        die('Error de Conexión (' . $conn->connect_errno . ') '
                . $conn->connect_error);
    }
    $conn->set_charset("utf8");
    return $conn;
}
