<?php
    require_once "model_clientes.php"
    
    $usuarios = clientes_get_all();
?>
<html>
<head>
</head>
<body>
    <table>
        <thead>
            <th>NOMBRE</th> 
            <th>APELLIDOS</th>
            <th>USERNAME</th>
            <th>ACCIONES</th>
        </thead>
        <tbody>
            <?php foreach($usuarios as $u) : ?>
                <tr>
                    <td><?php echo $u['nombre']; ?></td>
                    <td><?php echo $u['apellidos']; ?></td>
                    <td><?php echo $u['username']; ?></td>
                    <td>
                        <a href="edit_client.php?id=<?php echo $u['id']?>">Editar</a>
                        <a href="delete_client.php?id=<?php echo $u['id']?>">Borrar</a>
                    </td>
                </tr>
            <?php endforeach ?>
        </tbody>
    </table>
</body>
</html>