<?php
    $datos = [
        ['nombre'=>'AAA', 'apellidos'=>'AAA', 'dni'=>'111111A'],
        ['nombre'=>'BBB', 'apellidos'=>'BBB', 'dni'=>'111111B'],
        ['nombre'=>'CCC', 'apellidos'=>'CCC', 'dni'=>'111111C']
    ];

    $f = fopen("datos.dat", "w");
    foreach($datos as $d) {
        fprintf($f, "%s;%s;%s".PHP_EOL, $d['nombre'], $d['apellidos'], $d['dni']);
    }
    fclose($f);

    $lineas = file('datos.dat');    // Para ficheros pequeños
    foreach($lineas as $linea) {
        $fields = str_getcsv($linea, ";");
        echo printf("nombre=%s apellidos=%s dni=%s<br />", $fields[0], $fields[1], $fields[2]);
    }
    
