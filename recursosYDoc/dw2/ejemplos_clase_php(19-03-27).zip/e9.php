<?php
    // Script que se invoca de la sigueinte manera
    // e9.php?id=<numero>&data=<cadena>

    $log = null;

    // Log: archivo con entradas de tipo
    // [FECHA] [TYPE]: [MSG]
    //      TYPE = [error, warn, info]

    $ip_addr = $_SERVER['REMOTE_ADDR'];
    $id = $_GET['id'];
    $data = $_GET['data'];

    log_init($log);

    log_write($log, 'info', 'Usuario se conectó desde '.$ip_addr);
    if( $ip_addr=='127.0.0.1' || $ip_addr=='::1' ) {
        log_write($log, 'warn', 'Acceso local ');
    }

    if( $id=='' || !is_numeric($id) ) {
        log_write($log, 'error', 'Bad parameter id ('.$id.')');         
    }
    if( $data=='' ) {
        log_error($log, 'Bad parameter data ('.$data.')');         
    }    

    if( strlen($data)>10 ) {
        log_write($log, 'warn', 'Data too long ('.$data.')');         
    }    


    function log_init(&$log)
    {
        $log = fopen("app.log", "a");
    }

    function log_write(&$log, $type, $msg) 
    {
        $now = new \DateTime();

        // Rotate the log
        $lines = file("app.log");
        if( count($lines)>10 ) {
            $fold = fopen('app-'.$now->format('YmdHis').'.log', "w");
            fputs($fold, implode("", $lines));
            fclose($fold);
            fclose($log);
            unlink("app.log");
            $log = fopen('app.log', "a");
        }

        fprintf($log, "%s %s|%s\n",
            $now->format("Y-m-d H:i:s"),
            $type,
            $msg
        );
    }

    function log_info(&$log, $msg) 
    {
        log_write($log, 'info', $msg);
    }

    function log_warn(&$log, $msg) 
    {
        log_write($log, 'warn', $msg);
    }    

    function log_error(&$log, $msg) 
    {
        log_write($log, 'error', $msg);
    }    