<?php
    require_once 'e8_model/usuarios.php';
    
    session_start();    // Recupera la session existente
    if( isset($_SESSION['app1263467367346_islogged']) ) {

    $users = usuarios_get_all();
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ejemplo 8  Listado de usuarios</title>
</head>
<body>
    <p style="text-align: right">
        <a href="e8_logout.php">Salir</a>
    </p>
    <table>
        <thead>
            <th>ID</th>
            <th>NOMBRE</th>
            <th>APELLIDOS</th>
            <th>ACCIONES</th>
        </thead>
        <tbody>
            <?php foreach($users as $u) : ?>
                <tr>
                    <td><?php echo $u['id'];?></td>
                    <td><?php echo $u['nombre'];?></td>
                    <td><?php echo $u['apellidos'];?></td>
                    <td style="font-size: 0.6em">
                        <a href="e8_edit.php?id=<?php echo $u['id'];?>">Editar</a>
                        <a href="e8_delete.php?id=<?php echo $u['id'];?>">Borrar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</body>
</html>
<?php
    }
    else {
        header('Location: e8_login.php');
        exit;
    }
?>