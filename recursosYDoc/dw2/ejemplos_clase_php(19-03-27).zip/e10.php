<?php
    require_once 'e8_model/usuarios.php';
    if( $_SERVER['REQUEST_METHOD']=='GET') {

        $archivos = json_decode(file_get_contents('/xampp/appdata/e10/archivos.json'), true);            
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ejemplo 10. Subida y descarga de archivos</title>
</head>
<body>
    <p>
        <h1>Subir archivo</h1>
        <form method="post" enctype="multipart/form-data">
            <p>
                Nombre <input type="file" id="archivo1" name="archivo1" />
            </p>
            <p>
                <input type="submit" value="Guardar" />
            </p>
        </form>
    </p>
    <p>
        <h1>Archivos subidos</h1>
        <table>
            <tr>
                <td>Nombre</td> <td>Tipo</td> <td>Tamaño</td> <td>Miniatura</td> <td></td>
            </tr>
            <?php foreach($archivos as $a) : ?>
            <tr>
                <td><?php echo $a['nombre'];?></td> 
                <td><?php echo $a['tipo'];?></td> 
                <td><?php echo $a['size'];?></td> 
                <td>
                    <?php
                        if( array_search($a['tipo'], [
                            'jpg' => 'image/jpeg',
                            'png' => 'image/png',
                            'gif' => 'image/gif', 
                        ])!==false ) {
                    ?>
                    <img src ="e10_download.php?id=<?php echo $a['id'];?>&action=view" width="100" height="auto">
                    <?php
                        }
                    ?>
                </td>
                <td><a target="_blank" href="e10_download.php?id=<?php echo $a['id'];?>">Descargar</a></td>
            </tr>
            <?php endforeach ?>
        </table>
    </p>
</body>
</html>
<?php
    }
    else if( $_SERVER['REQUEST_METHOD']=='POST') {
        // print_r($_FILES);; exit;
        try {
            // Undefined | Multiple Files | $_FILES Corruption Attack
            // If this request falls under any of them, treat it invalid.
            if (
                !isset($_FILES['archivo1']['error']) ||
                is_array($_FILES['archivo1']['error'])
            ) {
                throw new RuntimeException('Invalid parameters.');
            }
       
            // Check $_FILES['archivo1']['error'] value.
            switch ($_FILES['archivo1']['error']) {
                case UPLOAD_ERR_OK:
                    break;
                case UPLOAD_ERR_NO_FILE:
                    throw new RuntimeException('No file sent.');
                case UPLOAD_ERR_INI_SIZE:
                case UPLOAD_ERR_FORM_SIZE:
                    throw new RuntimeException('Exceeded filesize limit.');
                default:
                    throw new RuntimeException('Unknown errors.');
            }
       
            // You should also check filesize here. 
            if ($_FILES['archivo1']['size'] > 2*1024*1024) {
                throw new RuntimeException('Exceeded filesize limit.');
            }
       
            // DO NOT TRUST $_FILES['upfile']['mime'] VALUE !!
            // Check MIME Type by yourself.
            $finfo = new finfo(FILEINFO_MIME_TYPE);
            $mimetype = $finfo->file($_FILES['archivo1']['tmp_name']);
            if (false === $ext = array_search(
                $mimetype,
                array(
                    'jpg' => 'image/jpeg',
                    'png' => 'image/png',
                    'gif' => 'image/gif',
                    'pdf' => 'application/pdf',
                ),
                true
            )) {
                throw new RuntimeException('Invalid file format.');
            }
       
            // You should name it uniquely.
            // DO NOT USE $_FILES['upfile']['name'] WITHOUT ANY VALIDATION !!
            // On this example, obtain safe unique name from its binary data.
            if( !is_dir('/xampp/appdata/e10/files') ) {
                mkdir('/xampp/appdata/e10/files',0777,true);
            }

            $id = sha1_file($_FILES['archivo1']['tmp_name']);
            $filename = sprintf('/xampp/appdata/e10/files/%s',$id);
            
            $existe = false;
            $archivos = json_decode(file_get_contents('/xampp/appdata/e10/archivos.json'), true);
            foreach($archivos as $a) {
                if( $id == $a['id'] ) {
                    $existe = true;
                    break;
                }
            }

            // FJP: Esta parte (subida fisica) hay que obviarla si ya esta 
            // subido el archivo
                        
            if (!$existe && !move_uploaded_file(
                $_FILES['archivo1']['tmp_name'],
                $filename
            )) {
                throw new RuntimeException('Failed to move uploaded file.');
            }

            // FJP: Esta parte (subida logica) hay que obviarla en aplicaciones de 1 usuario
            // si archivo ya lo subió. Si hay varios usuarios si se hace porque
            // puede que varios usuarios suban el mismo archivo y hay que registrarlo

            if( !$existe ) {
                $archivos[] = [
                     'id' => $id
                    ,'nombre' => $_FILES['archivo1']['name']
                    ,'tipo' => $mimetype
                    ,'size' => $_FILES['archivo1']['size']
                    ,'path' => $filename
                ]; 
                file_put_contents('/xampp/appdata/e10/archivos.json', json_encode($archivos, JSON_PRETTY_PRINT));
            }
       
            header('Location: e10.php');
            exit;

        } catch (RuntimeException $e) {
            echo $e->getMessage();
            exit;
        }
    }
?>