<?php
    $empleados = [
        '11111111A' => ['nombre'=>'Nombre1', 'apellidos'=>'Apellidos1','id'=>1],
        '11111111B' => ['nombre'=>'Nombre2', 'apellidos'=>'Apellidos2','id'=>2],
        '11111111C' => ['nombre'=>'Nombre3', 'apellidos'=>'Apellidos3','id'=>3]
    ];

    $clientes = [
        '11111111D' => ['nombre'=>'Nombre4', 'apellidos'=>'Apellidos4'],
        '11111111E' => ['nombre'=>'Nombre5', 'apellidos'=>'Apellidos5']
    ];