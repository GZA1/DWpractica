<?php
    require_once 'e11/Persona.php';
    require_once 'e11/Empleado.php';
    require_once 'e11/Cliente.php';


    $usu1 = new Persona();
    $usu1->setNombre('AAA')
         ->setApellidos('AAA')
         ->setDni('11111111A')
    ;

    $usu2 = new Empleado();
    $usu2->setNombre('BBB')
         ->setApellidos('BBB')
         ->setDni('11111111B')
         ->setEid('1001')
    ;

    $usu3 = new Cliente();
    $usu3->setNombre('CCC')
         ->setApellidos('CCC')
         ->setDni('11111111C')
         ->setCid('CL1005')
    ;


    $gen = new StdClass();
    $gen->nombre = "AAA";
    $gen->edad = 24;

    $array_assoc = (array)$gen;

?>
<!DOCTYPE html>
<html>
<head>
    <title>Ejemplo 11 orientacion a objetos</title>
</head>
<body>
    <p>
    <?php echo $usu1->getId().' '.$usu1->getFullname(); ?>
    </p>

    <p>
    <?php echo $usu2->getId().' '.$usu2->getFullname().' '.$usu2->getEid(); ?>
    </p>    

    <p>
    <?php echo $usu3->getId().' '.$usu3->getFullname().' '.$usu3->getCid(); ?>
    </p>      

    <p>
    <?php $json = $usu3->toJson(); echo $json; ?>
    </p>     

    <p>
    <?php $s3 = serialize($usu3); echo $s3 ?>
    </p>      

    <p>
    <?php $o3 = unserialize($s3); echo $o3->getFullname() ?>
    </p>          

    <p>
    <?php $o4 = Cliente::fromJson($json); echo $o4->getFullname() ?>
    </p> 

</body>
</html>