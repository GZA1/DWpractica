<?php
    $id = $_GET['id'];

    $file = null;
    $archivos = json_decode(file_get_contents('/xampp/appdata/e10/archivos.json'), true);
    foreach($archivos as $a) {
        if( $id == $a['id'] ) {
            $file = $a;
            break;
        }
    }

    // FJP: En aplicaciones multiusuario, ademas de comprobar que el fichero
    // existe, habra que comprobar que el usuario que realiza la peticion
    // tiene "permisos" para descargar ese fichero

    if( !isset($_GET['action']) || $_GET['action']=='download' ) {
        header('Content-Type: "application/octet-stream"');
    }
    else if( $_GET['action']=='view' ) {
        header('Content-Type: "'.$file['tipo'].'"');
    }
    header('Content-Disposition: attachment; filename="'.$file['nombre'].'"');
    header("Content-Transfer-Encoding: binary");
    header('Expires: 0');
    header('Pragma: no-cache');
    header("Content-Length: ".$file['size']);

    readfile($file['path']);
    exit;
?>