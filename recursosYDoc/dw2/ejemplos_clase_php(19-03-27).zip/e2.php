<!DOCTYPE html>
<html>
<head>
    <title>Ejemplo 1  PHP</title>
</head>
<body>
    <?php
        $numero1 = 3;
        $numero2 = 5;
        $numero3 = 4.5;
        $numero4 = "10";
        $numero5 = 10;
        $numero6 = ($numero4.'0') ** 2;
    ?>
    <p>
        <ul>
            <li>numero1 = <?php echo $numero1; ?></li>
            <li>numero2 = <?php echo $numero2; ?></li>
            <li>numero3 = <?php echo $numero3; ?></li>
            <li>numero4 = <?php echo $numero4; ?></li>
            <li>numero6 = <?php echo $numero6; ?></li>
        </ul>
    </p>
    <p>
        <ul>
            <li>numero1 + numero3 = <?php echo $numero1 + $numero3; ?></li>
            <li>numero1 * numero4 = <?php echo $numero1 * $numero4; ?></li>
            <li>numero1 ** numero2 = <?php echo $numero1 ** $numero2; ?></li>
        </ul>
    </p>
    <p>
        <ul>
            <li>numero1 == numero3 = <?php echo $numero1 == $numero3 ? 'true' : 'false'; ?></li>
            <li>numero4 == numero5 = <?php echo $numero4 == $numero5 ? 'true' : 'false'; ?></li>
            <li>numero4 === numero5 = <?php echo $numero4 === $numero5 ? 'true' : 'false'; ?></li>
        </ul>
    </p>    
</body>
</html>