<?php
    require_once 'e8_model/login.php';

    if( $_SERVER['REQUEST_METHOD']=='GET') {
?>
<!DOCTYPE html>
<html>
<head>
    <title>Ejemplo 8  Login</title>
</head>
<body>
    <form method="post">
        <p>
            Usuario <input type="text" id="username" name="username" />
        </p>
        <p>
            Password <input type="password" id="password" name="password" />
        </p>
        <p>
            <input type="submit" value="Acceder" />
        </p>
    </form>
</body>
</html>
<?php
    }
    else if( $_SERVER['REQUEST_METHOD']=='POST') {
        $result = login_check($_POST['username'], md5($_POST['password']));
        if( $result ) {
            // Creo una sesion nueva
            session_start();
            $_SESSION['app1263467367346_islogged'] = true;
            $_SESSION['username'] = $_POST['username'];
            $_SESSION['ip'] = $_SERVER['REMOTE_ADDR'];
            header('Location: e8_list_users.php');
            exit;
        }
        else {
            header('Location: e8_login.php?error=1');
            exit;
        }
    }
?>